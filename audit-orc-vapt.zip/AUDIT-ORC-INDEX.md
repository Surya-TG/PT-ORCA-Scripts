<!-- L1 ORC-NAV — read MRK:NAV_TOC first; fetch MRK ranges precisely (no default line count) -->
<!-- L2 NAV:v1 → [project root] -->

<!-- MRK:AUDIT_ORC_INDEX_NAV_TOC — Section index | nav,toc,index | L4-29 -->
<!-- - MRK:INDEX_PROTOCOL — Access protocol | index,protocol,access | L30-36 -->
<!-- - MRK:INDEX_RULES — Hard rules | index,rules,hard | L37-45 -->
<!-- - MRK:INDEX_TOOL — Reindex tool reference | index,tool,reindex,reference | L46-58 -->
<!-- - MRK:INDEX_FILES — Files by directory | index,directory | L59-430 -->
<!-- - MRK:INDEX_ALL — All anchors (flat, 450 entries) | index,anchors,flat,entries | L431-887 -->
<!-- NAV-LEN: 5 entries | Integrity-hash: f568eac63293f2ac | Last-indexed: 2026-04-27T17:32:58Z -->

<!-- BEGIN USER-PROMPT (preserved across reindex — edit this block to add project context) -->
<!--
    PROJECT CONTEXT / OWNER GUIDELINES
    (Empty by default. Add engagement-specific or project-specific context
    here: target scope, goals, constraints, tester profile, anything that
    orients an LLM faster. Reindex PRESERVES this block — it's never
    overwritten by `orc-nav-reindex.py index`.)
-->
<!-- END USER-PROMPT -->

<!-- tool-sha: 0be970553e963222 | orc-nav-reindex.py -->

# AUDIT-ORC-INDEX — audit-orc

ORCa / PT-Orc-Suite — TechGuard release (v1)

**Files indexed:** 63 &nbsp;·&nbsp; **Anchors:** 462 &nbsp;·&nbsp; **Last-indexed:** 2026-04-27T17:32:58Z

## MRK:INDEX_PROTOCOL — Access protocol | index,protocol,access | L30-36

1. **Read the file header first.** Every indexed file has L1 (rules) + L2 (`NAV:v1 → <path>`) on lines 1–2 (MD) or 2–3 (shebang script). `tail -2` gives the same orientation from the bottom (mirror).
2. **Use the per-file `MRK:NAV_TOC` block.** Each file carries a TOC listing entries with exact `L<start>-<end>` ranges. Match by keyword; fetch by range.
3. **Precise fetch only.** Use `L<start>-<end>` from the MRK line. No default line count. Range missing / stale → run `reindex` before reading.
4. **Miss? Log it.** When a TOC lookup didn't contain what you expected, record in `session_lessons_log.md` (see `/orc-nav` skill). No inference effort is wasted.

## MRK:INDEX_RULES — Hard rules | index,rules,hard | L37-45

- Never open a file without a stated purpose.
- Never bulk-read an indexed file — use the TOC.
- Never re-load a file already in context — recall from memory.
- Loading >200 lines without a target → state in one sentence what you're looking for first.
- After adding/renaming/removing any MRK anchor → run `reindex` before commit.
- Before every commit → run the composite `reindex + verify`.

## MRK:INDEX_TOOL — Reindex tool reference | index,tool,reindex,reference | L46-58

```
python tools/orc-nav-reindex.py reindex             # write pass — refresh ranges + hashes after edits
python tools/orc-nav-reindex.py verify              # read pass — integrity check (pre-commit)
python tools/orc-nav-reindex.py index               # regenerate this file
python tools/orc-nav-reindex.py append <file>       # add one NAV:v1 file's entry into this index
python tools/orc-nav-reindex.py append <file> --index <idx>  # target a specific index
./tools/pt-orc-reindex.sh --pre-commit              # composite: reindex + verify
```

Always run the pre-commit composite before `git commit`. Drift → fix source, retry.

## MRK:INDEX_FILES — Files by directory | index,directory | L59-430

### `.in/.in-index.md` — 1 anchors
- `MRK:IN_INDEX_FILES` — Files in this directory

### `.in/.processed/NOTES-from-NAV_CORE-domain-model-fixes_20260426-222847.md` — 1 anchors
- `MRK:NOTES_BODY` — Message body

### `.in/.processed/NOTES-from-NAV_CORE-nav-v1-skills-ready_20260427-000000.md` — 1 anchors
- `MRK:NOTES_BODY` — Message body

### `.in/DCPTCN_TG_beacon.md` — 1 anchors
- `MRK:DCPTCN_TG_BEACON` — DCPTCN_TG project beacon

### `.in/ORCA-SLIDES_beacon.md` — 1 anchors
- `MRK:ORCA_SLIDES_BEACON` — ORCA-SLIDES project beacon

### `.in/ORCA_DOCS_beacon.md` — 1 anchors
- `MRK:ORCA_DOCS_BEACON` — ORCA_DOCS project beacon

### `.in/ORCA_RELEASE_beacon.md` — 1 anchors
- `MRK:ORCA_RELEASE_BEACON` — ORCA_RELEASE project beacon

### `.in/README.md` — 4 anchors
- `MRK:IN_README_PROTOCOL` — Access protocol (P1 v3)
- `MRK:IN_README_RULES` — Hard rules (P2 v2)
- `MRK:IN_README_CONFLICT` — Conflict-resolution
- `MRK:IN_README_CUSTOM` — Custom context (preserved)

### `.in/SPEC-DCPTCN_TG-orientation-20260427-132500.md` — 6 anchors
- `MRK:DCPTCN_SPEC_STATUS` — Status & delivery target
- `MRK:DCPTCN_SPEC_ENGMODEL` — Generic engagement model
- `MRK:DCPTCN_SPEC_METHODOLOGY` — Unified methodology lifecycle
- `MRK:DCPTCN_SPEC_DECEPTICON` — Decepticon planner generalization
- `MRK:DCPTCN_SPEC_ARCH` — Architecture bottom line
- …

### `AUDIT-ORC-INDEX.md` — 5 anchors
- `MRK:INDEX_PROTOCOL` — Access protocol
- `MRK:INDEX_RULES` — Hard rules
- `MRK:INDEX_TOOL` — Reindex tool reference
- `MRK:INDEX_FILES` — Files by directory
- `MRK:INDEX_ALL` — All anchors (flat, 438 entries)

### `CHANGELOG.md` — 2 anchors
- `MRK:RELEASE_V081` — v0.8.1 — 2026-04-21
- `MRK:RELEASE_V08` — v0.8 — 2026-04-20

### `NAV-MAIN-INDEX.md` — 1 anchors
- `MRK:NAV_MAIN_PROJECTS` — Project registry

### `NOTICE.md` — 6 anchors
- `MRK:NOTICE_COMPONENTS` — Components
- `MRK:NOTICE_PTORC` — PT-Orc suite
- `MRK:NOTICE_ORCNAV` — ORC NAV system
- `MRK:NOTICE_LICENSING` — Licensing
- `MRK:NOTICE_CONTACT` — Contact
- …

### `docs/nav-v1-user-guide.md` — 12 anchors
- …

### `docs/system-assessment-v1-initial.md` — 6 anchors
- `MRK:ASSESS_OVERVIEW` — Assessment basis and scope
- `MRK:ASSESS_SYSTEM` — What the system is
- `MRK:ASSESS_STRENGTHS` — What works genuinely well
- `MRK:ASSESS_GAPS` — Where it is strained
- `MRK:ASSESS_VERDICT` — Overall verdict and recommendation
- …

### `nav-orc/skills/nav/SKILL.md` — 1 anchors
- `MRK:NAV_DISPATCH` — On activation: bootstrap nav_bare + nav_profile

### `nav-orc/skills/nav_action_plan_proc/SKILL.md` — 13 anchors
- `MRK:NVAAP_PURPOSE` — Purpose and trigger table
- `MRK:NVAAP_PERSIST` — Persistent layer overview
- `MRK:NVAAP_TASKS` — Tasks (structured board)
- `MRK:NVAAP_SESSNOTES` — Session notes
- `MRK:NVAAP_REMINDERS` — Reminders
- …

### `nav-orc/skills/nav_bare/SKILL.md` — 8 anchors
- `MRK:NBARE_PURPOSE` — Purpose + scope
- `MRK:NBARE_DETECT` — NAV:v1 detection
- `MRK:NBARE_READ_ORDER` — Read-order protocol
- `MRK:NBARE_ORIENT` — Domain orientation via MAIN-INDEX
- `MRK:NBARE_NAVRULE_READ` — NAV-RULE read gates
- …

### `nav-orc/skills/nav_commit/SKILL.md` — 5 anchors
- `MRK:NCMT_PIPELINE` — 4-step commit pipeline
- `MRK:NCMT_O1` — O-1 MAIN-INDEX join rule
- `MRK:NCMT_SAMECOMMIT` — Same-commit coupling check
- `MRK:NCMT_GIT` — Git commit pattern
- `MRK:NCMT_PERMS` — Permissions

### `nav-orc/skills/nav_core/SKILL.md` — 12 anchors
- `MRK:NAVSKILL_PREREQS` — Prerequisites
- `MRK:NAVSKILL_DETECT` — Detect
- `MRK:NAVSKILL_READORDER` — Read-order protocol
- `MRK:NAVSKILL_EDITPROTO` — Edit protocol
- `MRK:NAVSKILL_NAVRULE` — NAV-RULE syntax, alerts, placement
- …

### `nav-orc/skills/nav_ext/SKILL.md` — 11 anchors
- `MRK:NAVEXT_PURPOSE` — Scope and load triggers
- `MRK:NAVEXT_AUTOLOAD` — Full suite auto-load on nav_ext load
- `MRK:NAVEXT_IO` — I/O accounting (R/W/S)
- `MRK:NAVEXT_MISSES` — Miss taxonomy + session logging
- `MRK:NAVEXT_GAPDET` — Gap detection (dev mode)
- …

### `nav-orc/skills/nav_profile/SKILL.md` — 11 anchors
- `MRK:NAVPROFILE_PREREQS` — Prerequisites and pairs
- `MRK:NAVPROFILE_AUTH_MODEL` — Auth model (tiers + domain access)
- `MRK:NAVPROFILE_AUTH_IMPL` — Auth implementation + alternatives
- `MRK:NAVPROFILE_DOMAINS` — Domain access registry
- `MRK:NAVPROFILE_ROLES` — Role frames
- …

### `nav-orc/skills/nav_project_proc/SKILL.md` — 15 anchors
- `MRK:NAVPP_PURPOSE` — Scope and trigger table
- `MRK:NAVPP_PROJECT` — Project workflow
- `MRK:NAVPP_BEACON` — Beacon schema + message lifecycle
- `MRK:NAVPP_HANDOVER` — Handover, close, pause, rename
- `MRK:NAVPP_MAININDEX` — NAV-MAIN-INDEX + project list
- …

### `nav-orc/spec/nav-v1-spec.md` — 36 anchors
- `MRK:NAVSPEC_CHANGELOG` — Changelog
- `MRK:NAVSPEC_PRINCIPLES` — Highest-priority principles
- `MRK:NAVSPEC_DELIVERY` — Delivery scope and boundaries
- `MRK:NAVSPEC_PURPOSE` — Purpose
- `MRK:NAVSPEC_CORE` — Core concept
- …

### `nav-orc/tools/README.md` — 4 anchors
- `MRK:TOOLS_README_PROTOCOL` — Access protocol (P1 v3)
- `MRK:TOOLS_README_RULES` — Hard rules (P2 v2)
- `MRK:TOOLS_README_CONFLICT` — Conflict-resolution
- `MRK:TOOLS_README_CUSTOM` — Custom context (preserved)

### `nav-orc/tools/orc-nav-reindex.py` — 13 anchors
- `MRK:REINDEX_CONSTANTS` — Module constants and configuration
- `MRK:REINDEX_DETECT` — File type detection
- `MRK:REINDEX_PARSE` — Anchor and TOC parsing
- `MRK:REINDEX_STRIP` — Legacy format stripping
- `MRK:REINDEX_EMIT` — Output generation helpers
- …

### `nav-orc/tools/pt-orc-reindex.ps1` — 2 anchors
- `MRK:REINDEX_PS1_SETUP` — Setup: find Python tool + resolver
- `MRK:REINDEX_PS1_DISPATCH` — Flag dispatch

### `nav-orc/tools/pt-orc-reindex.sh` — 2 anchors
- `MRK:REINDEX_SH_SETUP` — Setup: find Python tool + resolver
- `MRK:REINDEX_SH_DISPATCH` — Flag dispatch

### `nav-orc/tools/tools-index.md` — 1 anchors
- `MRK:TOOLS_INDEX_FILES` — Files in this directory

### `pt-orc/correlations/README.md` — 0 anchors

### `pt-orc/correlations/correlations-index.md` — 1 anchors
- `MRK:CORRELATIONS_INDEX_FILES` — Files in this directory

### `pt-orc/docs/README.md` — 4 anchors
- `MRK:DOCS_README_PROTOCOL` — Access protocol (P1 v3)
- `MRK:DOCS_README_RULES` — Hard rules (P2 v2)
- `MRK:DOCS_README_CONFLICT` — Conflict-resolution
- `MRK:DOCS_README_CUSTOM` — Custom context (preserved)

### `pt-orc/docs/design.md` — 4 anchors
- `MRK:PATTERNS` — Shared Patterns
- `MRK:GOTCHAS` — Key Design Decisions and Gotchas
- `MRK:D03` — 03_comp_scan.sh Architecture
- `MRK:TOOLS` — Tool Dependencies

### `pt-orc/docs/docs-index.md` — 1 anchors
- `MRK:DOCS_INDEX_FILES` — Files in this directory

### `pt-orc/docs/funcs.md` — 9 anchors
- `MRK:CTX` — §0. Context
- `MRK:S00` — 00_pt-orc.sh
- `MRK:S01` — 01_dns_recon_v0.76.sh
- `MRK:S03` — 03_comp_scan.sh
- `MRK:S04` — 04_tls_scan_v0.76.sh
- …

### `pt-orc/docs/ops.md` — 5 anchors
- `MRK:OPS_SCRIPTS` — Scripts at a Glance
- `MRK:OPS_PIPELINE` — Pipeline
- `MRK:OPS_FLAGS` — CLI Flags
- `MRK:OPS_OPERATIONS` — Common Operations
- `MRK:OPS_DIRS` — Directory Structure

### `pt-orc/docs/orientation.md` — 6 anchors
- `MRK:IDX_S0` — §0. MRK Naming Convention
- `MRK:IDX_S1` — §1. Suite Overview
- `MRK:IDX_S2` — §2. Data Flow
- `MRK:IDX_S3` — §3. Engagement Config
- `MRK:IDX_S4` — §4. Evidence Directory Layout
- …

### `pt-orc/docs/skill-brief.md` — 15 anchors
- `MRK:SKL_HOWTO` — How to Use This File
- `MRK:SKL_S0` — §0. Skill Navigation Protocol — how the skill reads suite files efficiently
- `MRK:SKL_S1` — §1. Skill Role
- `MRK:SKL_S2` — §2. Reference File Loading Strategy
- `MRK:SKL_S3` — §3. State Snapshot Schema
- …

### `pt-orc/modules/README.md` — 0 anchors

### `pt-orc/modules/modules-index.md` — 1 anchors
- `MRK:MODULES_INDEX_FILES` — Files in this directory

### `pt-orc/scripts/00_pt-orc.sh` — 11 anchors
- `MRK:00_ROOT` — ROOT CHECK
- `MRK:00_CONF` — ENGAGEMENT CONFIG
- `MRK:00_LOG` — COLOURS AND LOGGING + STEP BANNER
- `MRK:00_DEFAULTS` — DEFAULTS + STEP STATUS ACCUMULATORS
- `MRK:00_USAGE` — USAGE BANNER
- …

### `pt-orc/scripts/01_dns_recon.sh` — 14 anchors
- `MRK:01_ROOT` — ROOT CHECK
- `MRK:01_CONF` — ENGAGEMENT CONFIGURATION
- `MRK:01_LOG` — COLOURS AND LOGGING
- `MRK:01_ARGS` — ARGUMENT PARSING
- `MRK:01_SRCIP` — SOURCE IP VERIFICATION
- …

### `pt-orc/scripts/02_ip_analysis.sh` — 12 anchors
- `MRK:02_LOG` — COLOURS AND LOGGING
- `MRK:02_CONF` — ENGAGEMENT CONFIGURATION
- `MRK:02_USAGE` — USAGE
- `MRK:02_ARGS` — ARGUMENT PARSING
- `MRK:02_DEPS` — DEPENDENCY CHECK
- …

### `pt-orc/scripts/03_comp_scan.sh` — 26 anchors
- `MRK:03_ROOT` — ROOT CHECK
- `MRK:03_CONF` — ENGAGEMENT CONFIGURATION
- `MRK:03_TIER` — STEALTH TIER PARAMETERS
- `MRK:03_LOG` — COLOURS AND LOGGING
- `MRK:03_ARGS` — ARGUMENT PARSING
- …

### `pt-orc/scripts/04_tls_scan.sh` — 11 anchors
- `MRK:04_ROOT` — ROOT CHECK
- `MRK:04_CONF` — ENGAGEMENT CONFIGURATION
- `MRK:04_LOG` — COLOURS AND LOGGING
- `MRK:04_DB` — MSF DB CREDENTIALS
- `MRK:04_ARGS` — ARGUMENT PARSING
- …

### `pt-orc/scripts/05_web_enum.sh` — 11 anchors
- `MRK:05_ROOT` — ROOT CHECK
- `MRK:05_CONF` — ENGAGEMENT CONFIGURATION
- `MRK:05_LOG` — COLOURS AND LOGGING
- `MRK:05_ARGS` — ARGUMENT PARSING
- `MRK:05_DB` — MSF DB HELPERS
- …

### `pt-orc/scripts/06_wpscan.sh` — 13 anchors
- `MRK:06_LOG` — COLOURS AND LOGGING
- `MRK:06_CONF` — ENGAGEMENT CONFIGURATION
- `MRK:06_USAGE` — USAGE
- `MRK:06_ARGS` — ARGUMENT PARSING
- `MRK:06_DEPS` — DEPENDENCY CHECK
- …

### `pt-orc/scripts/07_service_verify.sh` — 34 anchors
- `MRK:07_ROOT` — ROOT CHECK
- `MRK:07_CONF` — ENGAGEMENT CONFIGURATION
- `MRK:07_LOG` — COLOURS AND LOGGING
- `MRK:07_ARGS` — ARGUMENT PARSING
- `MRK:07_DB` — MSF DB + MODULE RUNNER
- …

### `pt-orc/scripts/README.md` — 4 anchors
- `MRK:SCRIPTS_README_PROTOCOL` — Access protocol (P1 v3)
- `MRK:SCRIPTS_README_RULES` — Hard rules (P2 v2)
- `MRK:SCRIPTS_README_CONFLICT` — Conflict-resolution
- `MRK:SCRIPTS_README_CUSTOM` — Custom context (preserved)

### `pt-orc/scripts/orc-common-lib.sh` — 4 anchors
- `MRK:COM_DB` — MSF / POSTGRES DIRECT ACCESS
- `MRK:COM_TRAIL` — MSF NOTES WRITER
- `MRK:COM_BANNER` — standalone banner
- `MRK:COM_SELFTEST` — reserved for future --test mode

### `pt-orc/scripts/scripts-index.md` — 1 anchors
- `MRK:SCRIPTS_INDEX_FILES` — Files in this directory

### `pt-orc/skills/pt-commands/SKILL.md` — 21 anchors
- `MRK:PT_CMDS_PASSIVE_CAPTURE` — GROUP: PASSIVE / CAPTURE
- `MRK:PT_CMDS_DNS_OSINT` — GROUP: DNS / OSINT
- `MRK:PT_CMDS_SWEEP` — GROUP: SWEEP
- `MRK:PT_CMDS_SMB` — GROUP: SMB
- `MRK:PT_CMDS_NFS` — GROUP: NFS
- …

### `pt-orc/skills/pt-enum/SKILL.md` — 7 anchors
- `MRK:PT_ENUM_RECEIVED` — Received from L1 (pt-orc)
- `MRK:PT_ENUM_EXIT` — Exit Criteria
- `MRK:PT_ENUM_DISPATCH` — L3 Dispatch Table
- `MRK:PT_ENUM_APPROACH` — Enumeration Approach by Stage
- `MRK:PT_ENUM_STUB_SCHEMA` — Finding Stub Schema
- …

### `pt-orc/skills/pt-evidence/SKILL.md` — 5 anchors
- `MRK:PT_EVIDENCE_RECEIVED` — Received from L1 (pt-orc)
- `MRK:PT_EVIDENCE_EXIT` — Exit Criteria
- `MRK:PT_EVIDENCE_PIPELINE` — Processing Pipeline
- `MRK:PT_EVIDENCE_TOOL_GUIDE` — Tool Output Interpretation Guide
- `MRK:PT_EVIDENCE_OUTPUT` — Output — Evidence Processing Block

### `pt-orc/skills/pt-monitor/SKILL.md` — 10 anchors
- `MRK:MON_ACTIVATE` — Activate when
- `MRK:MON_FIRSTREAD` — First read
- `MRK:MON_CORELOOP` — Core loop
- `MRK:MON_CADENCE` — /loop cadence
- `MRK:MON_ANOMALY` — Anomaly discipline
- …

### `pt-orc/skills/pt-orc/SKILL.md` — 12 anchors
- `MRK:PTORC_ROLE` — Role
- `MRK:PTORC_PRINCIPLES` — Core Principles (Immutable)
- `MRK:PTORC_NAMING` — Engagement Naming
- `MRK:PTORC_DIRS` — Directory Structure
- `MRK:PTORC_STAGES` — Stage Registry
- …

### `pt-orc/skills/pt-recon/SKILL.md` — 6 anchors
- `MRK:PT_RECON_RECEIVED` — Received from L1 (pt-orc)
- `MRK:PT_RECON_EXIT` — Exit Criteria
- `MRK:PT_RECON_S1` — S1 — Passive Reconnaissance
- `MRK:PT_RECON_S2` — S2 — Broad Sweep / Surface Mapping
- `MRK:PT_RECON_RETURN` — Return Pass Behaviour
- …

### `pt-orc/skills/pt-report/SKILL.md` — 20 anchors
- `MRK:PT_REPORT_RECEIVED` — Received from L1 (pt-orc)
- `MRK:PT_REPORT_INPUTS` — Input Sources
- `MRK:PT_REPORT_EXIT` — Exit Criteria
- `MRK:PT_REPORT_STRUCTURE` — Report Structure (PTI / PTE)
- `MRK:PT_REPORT_VERSIONING` — Document Versioning
- …

### `pt-orc/templates/README.md` — 0 anchors

### `pt-orc/templates/templates-index.md` — 1 anchors
- `MRK:TEMPLATES_INDEX_FILES` — Files in this directory

### `pt-orc/tools/README.md` — 4 anchors
- `MRK:TOOLS_README_PROTOCOL` — Access protocol (P1 v3)
- `MRK:TOOLS_README_RULES` — Hard rules (P2 v2)
- `MRK:TOOLS_README_CONFLICT` — Conflict-resolution
- `MRK:TOOLS_README_CUSTOM` — Custom context (preserved)

### `pt-orc/tools/install-skills.sh` — 5 anchors
- `MRK:INSTALL_SKILLS_SETUP` — Setup + arg parsing
- `MRK:INSTALL_SKILLS_SELECTION` — Skill selection (default vs all)
- `MRK:INSTALL_SKILLS_HELPERS` — Hash helpers + counters
- `MRK:INSTALL_SKILLS_MAIN_LOOP` — Main install loop with drift check
- `MRK:INSTALL_SKILLS_SUMMARY` — Summary output

### `pt-orc/tools/tools-index.md` — 1 anchors
- `MRK:TOOLS_INDEX_FILES` — Files in this directory

## MRK:INDEX_ALL — All anchors (flat, 450 entries) | index,anchors,flat,entries | L431-887

| File | Line | Tag | Title |
|------|------|-----|-------|
| `.in/.in-index.md` | L8 | `MRK:IN_INDEX_FILES` | Files in this directory |
| `.in/.processed/NOTES-from-NAV_CORE-domain-model-fixes_20260426-222847.md` | L8 | `MRK:NOTES_BODY` | Message body |
| `.in/.processed/NOTES-from-NAV_CORE-nav-v1-skills-ready_20260427-000000.md` | L8 | `MRK:NOTES_BODY` | Message body |
| `.in/DCPTCN_TG_beacon.md` | L8 | `MRK:DCPTCN_TG_BEACON` | DCPTCN_TG project beacon |
| `.in/ORCA-SLIDES_beacon.md` | L8 | `MRK:ORCA_SLIDES_BEACON` | ORCA-SLIDES project beacon |
| `.in/ORCA_DOCS_beacon.md` | L8 | `MRK:ORCA_DOCS_BEACON` | ORCA_DOCS project beacon |
| `.in/ORCA_RELEASE_beacon.md` | L8 | `MRK:ORCA_RELEASE_BEACON` | ORCA_RELEASE project beacon |
| `.in/README.md` | L11 | `MRK:IN_README_PROTOCOL` | Access protocol (P1 v3) |
| `.in/README.md` | L18 | `MRK:IN_README_RULES` | Hard rules (P2 v2) |
| `.in/README.md` | L27 | `MRK:IN_README_CONFLICT` | Conflict-resolution |
| `.in/README.md` | L35 | `MRK:IN_README_CUSTOM` | Custom context (preserved) |
| `.in/SPEC-DCPTCN_TG-orientation-20260427-132500.md` | L13 | `MRK:DCPTCN_SPEC_STATUS` | Status & delivery target |
| `.in/SPEC-DCPTCN_TG-orientation-20260427-132500.md` | L22 | `MRK:DCPTCN_SPEC_ENGMODEL` | Generic engagement model |
| `.in/SPEC-DCPTCN_TG-orientation-20260427-132500.md` | L41 | `MRK:DCPTCN_SPEC_METHODOLOGY` | Unified methodology lifecycle |
| `.in/SPEC-DCPTCN_TG-orientation-20260427-132500.md` | L83 | `MRK:DCPTCN_SPEC_DECEPTICON` | Decepticon planner generalization |
| `.in/SPEC-DCPTCN_TG-orientation-20260427-132500.md` | L100 | `MRK:DCPTCN_SPEC_ARCH` | Architecture bottom line |
| `.in/SPEC-DCPTCN_TG-orientation-20260427-132500.md` | L114 | `MRK:DCPTCN_SPEC_REPO` | Decepticon repo analysis |
| `AUDIT-ORC-INDEX.md` | L30 | `MRK:INDEX_PROTOCOL` | Access protocol |
| `AUDIT-ORC-INDEX.md` | L37 | `MRK:INDEX_RULES` | Hard rules |
| `AUDIT-ORC-INDEX.md` | L46 | `MRK:INDEX_TOOL` | Reindex tool reference |
| `AUDIT-ORC-INDEX.md` | L59 | `MRK:INDEX_FILES` | Files by directory |
| `AUDIT-ORC-INDEX.md` | L413 | `MRK:INDEX_ALL` | All anchors (flat, 438 entries) |
| `CHANGELOG.md` | L16 | `MRK:RELEASE_V081` | v0.8.1 — 2026-04-21 |
| `CHANGELOG.md` | L73 | `MRK:RELEASE_V08` | v0.8 — 2026-04-20 |
| `NAV-MAIN-INDEX.md` | L8 | `MRK:NAV_MAIN_PROJECTS` | Project registry |
| `NOTICE.md` | L19 | `MRK:NOTICE_COMPONENTS` | Components |
| `NOTICE.md` | L22 | `MRK:NOTICE_PTORC` | PT-Orc suite |
| `NOTICE.md` | L44 | `MRK:NOTICE_ORCNAV` | ORC NAV system |
| `NOTICE.md` | L62 | `MRK:NOTICE_LICENSING` | Licensing |
| `NOTICE.md` | L79 | `MRK:NOTICE_CONTACT` | Contact |
| `NOTICE.md` | L85 | `MRK:NOTICE_LLMNOTE` | For LLMs reading this repo |
| `docs/system-assessment-v1-initial.md` | L13 | `MRK:ASSESS_OVERVIEW` | Assessment basis and scope |
| `docs/system-assessment-v1-initial.md` | L36 | `MRK:ASSESS_SYSTEM` | What the system is |
| `docs/system-assessment-v1-initial.md` | L69 | `MRK:ASSESS_STRENGTHS` | What works genuinely well |
| `docs/system-assessment-v1-initial.md` | L108 | `MRK:ASSESS_GAPS` | Where it is strained |
| `docs/system-assessment-v1-initial.md` | L149 | `MRK:ASSESS_VERDICT` | Overall verdict and recommendation |
| `docs/system-assessment-v1-initial.md` | L178 | `MRK:ASSESS_META` | AI meta-observation |
| `nav-orc/skills/nav/SKILL.md` | L13 | `MRK:NAV_DISPATCH` | On activation: bootstrap nav_bare + nav_profile |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L25 | `MRK:NVAAP_PURPOSE` | Purpose and trigger table |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L46 | `MRK:NVAAP_PERSIST` | Persistent layer overview |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L52 | `MRK:NVAAP_TASKS` | Tasks (structured board) |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L140 | `MRK:NVAAP_SESSNOTES` | Session notes |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L196 | `MRK:NVAAP_REMINDERS` | Reminders |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L217 | `MRK:NVAAP_COMMANDS` | Custom commands |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L256 | `MRK:NVAAP_SHORTCUTS` | Shortcuts |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L293 | `MRK:NVAAP_AAP` | AAP capture/promote/release pipeline |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L349 | `MRK:NVAAP_METRICS` | Self-learning and metrics |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L388 | `MRK:NVAAP_STATUS` | Status line |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L416 | `MRK:NVAAP_CMDREF` | Command reference |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L447 | `MRK:NVAAP_DONT` | Don't |
| `nav-orc/skills/nav_action_plan_proc/SKILL.md` | L458 | `MRK:NVAAP_PERMS` | Permissions |
| `nav-orc/skills/nav_bare/SKILL.md` | L25 | `MRK:NBARE_PURPOSE` | Purpose + scope |
| `nav-orc/skills/nav_bare/SKILL.md` | L42 | `MRK:NBARE_DETECT` | NAV:v1 detection |
| `nav-orc/skills/nav_bare/SKILL.md` | L58 | `MRK:NBARE_READ_ORDER` | Read-order protocol |
| `nav-orc/skills/nav_bare/SKILL.md` | L77 | `MRK:NBARE_ORIENT` | Domain orientation via MAIN-INDEX |
| `nav-orc/skills/nav_bare/SKILL.md` | L107 | `MRK:NBARE_NAVRULE_READ` | NAV-RULE read gates |
| `nav-orc/skills/nav_bare/SKILL.md` | L131 | `MRK:NBARE_HANDOFF` | Hand-off for write/edit/reindex |
| `nav-orc/skills/nav_bare/SKILL.md` | L146 | `MRK:NBARE_DONT` | Don't list |
| `nav-orc/skills/nav_bare/SKILL.md` | L159 | `MRK:NBARE_PERMS` | Permissions (read-only) |
| `nav-orc/skills/nav_commit/SKILL.md` | L17 | `MRK:NCMT_PIPELINE` | 4-step commit pipeline |
| `nav-orc/skills/nav_commit/SKILL.md` | L49 | `MRK:NCMT_O1` | O-1 MAIN-INDEX join rule |
| `nav-orc/skills/nav_commit/SKILL.md` | L63 | `MRK:NCMT_SAMECOMMIT` | Same-commit coupling check |
| `nav-orc/skills/nav_commit/SKILL.md` | L79 | `MRK:NCMT_GIT` | Git commit pattern |
| `nav-orc/skills/nav_commit/SKILL.md` | L98 | `MRK:NCMT_PERMS` | Permissions |
| `nav-orc/skills/nav_core/SKILL.md` | L24 | `MRK:NAVSKILL_PREREQS` | Prerequisites |
| `nav-orc/skills/nav_core/SKILL.md` | L37 | `MRK:NAVSKILL_DETECT` | Detect |
| `nav-orc/skills/nav_core/SKILL.md` | L52 | `MRK:NAVSKILL_READORDER` | Read-order protocol |
| `nav-orc/skills/nav_core/SKILL.md` | L92 | `MRK:NAVSKILL_EDITPROTO` | Edit protocol |
| `nav-orc/skills/nav_core/SKILL.md` | L116 | `MRK:NAVSKILL_NAVRULE` | NAV-RULE syntax, alerts, placement |
| `nav-orc/skills/nav_core/SKILL.md` | L188 | `MRK:NAVSKILL_FILECREATE` | File creation rule |
| `nav-orc/skills/nav_core/SKILL.md` | L207 | `MRK:NAVSKILL_DIRECTORIES` | Directory conventions |
| `nav-orc/skills/nav_core/SKILL.md` | L247 | `MRK:NAVSKILL_REINDEX` | Reindex cheatsheet |
| `nav-orc/skills/nav_core/SKILL.md` | L272 | `MRK:NAVSKILL_DISPATCH` | Modular dispatch |
| `nav-orc/skills/nav_core/SKILL.md` | L294 | `MRK:NAVSKILL_DONT` | Don't |
| `nav-orc/skills/nav_core/SKILL.md` | L314 | `MRK:NAVSKILL_INVOKE` | When to invoke vs. skip |
| `nav-orc/skills/nav_core/SKILL.md` | L355 | `MRK:NAVSKILL_ROADMAP` | Roadmap pointers |
| `nav-orc/skills/nav_ext/SKILL.md` | L23 | `MRK:NAVEXT_PURPOSE` | Scope and load triggers |
| `nav-orc/skills/nav_ext/SKILL.md` | L43 | `MRK:NAVEXT_AUTOLOAD` | Full suite auto-load on nav_ext load |
| `nav-orc/skills/nav_ext/SKILL.md` | L71 | `MRK:NAVEXT_IO` | I/O accounting (R/W/S) |
| `nav-orc/skills/nav_ext/SKILL.md` | L122 | `MRK:NAVEXT_MISSES` | Miss taxonomy + session logging |
| `nav-orc/skills/nav_ext/SKILL.md` | L148 | `MRK:NAVEXT_GAPDET` | Gap detection (dev mode) |
| `nav-orc/skills/nav_ext/SKILL.md` | L165 | `MRK:NAVEXT_DBG_TOGGLE` | Debug toggle |
| `nav-orc/skills/nav_ext/SKILL.md` | L173 | `MRK:NAVEXT_DBG_EVENTS` | Debug event table |
| `nav-orc/skills/nav_ext/SKILL.md` | L189 | `MRK:NAVEXT_DBG_LEDGER` | Session-end ledger |
| `nav-orc/skills/nav_ext/SKILL.md` | L201 | `MRK:NAVEXT_PLACEMENT` | NAV-RULE placement rules (3-pass) |
| `nav-orc/skills/nav_ext/SKILL.md` | L227 | `MRK:NAVEXT_SPEC` | Spec quick-reference |
| `nav-orc/skills/nav_ext/SKILL.md` | L243 | `MRK:NAVEXT_PERMS` | Permissions |
| `nav-orc/skills/nav_profile/SKILL.md` | L23 | `MRK:NAVPROFILE_PREREQS` | Prerequisites and pairs |
| `nav-orc/skills/nav_profile/SKILL.md` | L35 | `MRK:NAVPROFILE_AUTH_MODEL` | Auth model (tiers + domain access) |
| `nav-orc/skills/nav_profile/SKILL.md` | L59 | `MRK:NAVPROFILE_AUTH_IMPL` | Auth implementation + alternatives |
| `nav-orc/skills/nav_profile/SKILL.md` | L93 | `MRK:NAVPROFILE_DOMAINS` | Domain access registry |
| `nav-orc/skills/nav_profile/SKILL.md` | L130 | `MRK:NAVPROFILE_ROLES` | Role frames |
| `nav-orc/skills/nav_profile/SKILL.md` | L155 | `MRK:NAVPROFILE_DATALOC` | Profile data location |
| `nav-orc/skills/nav_profile/SKILL.md` | L189 | `MRK:NAVPROFILE_DONT` | Don't list |
| `nav-orc/skills/nav_profile/SKILL.md` | L203 | `MRK:NAVPROFILE_PERMS` | Permissions |
| `nav-orc/skills/nav_profile/SKILL.md` | L215 | `MRK:NAVPROFILE_INVOKE` | Activation |
| `nav-orc/skills/nav_profile/SKILL.md` | L226 | `MRK:NAVPROFILE_AUTOLOAD` | Skill auto-load on nav_project_proc triggers |
| `nav-orc/skills/nav_profile/SKILL.md` | L264 | `MRK:NAVPROFILE_ROADMAP` | Roadmap pointers |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L27 | `MRK:NAVPP_PURPOSE` | Scope and trigger table |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L46 | `MRK:NAVPP_PROJECT` | Project workflow |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L166 | `MRK:NAVPP_BEACON` | Beacon schema + message lifecycle |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L228 | `MRK:NAVPP_HANDOVER` | Handover, close, pause, rename |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L311 | `MRK:NAVPP_MAININDEX` | NAV-MAIN-INDEX + project list |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L357 | `MRK:NAVPP_INIT` | Session initialization |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L372 | `MRK:NAVPP_SESSIONSYS` | Session system settings |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L388 | `MRK:NAVPP_NLC` | Near-lost-context dump |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L417 | `MRK:NAVPP_DEVMODE` | Dev mode + session start |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L436 | `MRK:NAVPP_SESSCLOSE` | Session close |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L475 | `MRK:NAVPP_TRACES` | Settlement traces |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L508 | `MRK:NAVPP_INFORMAT` | .in/ output file format + attachments |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L564 | `MRK:NAVPP_NPP` | Extended behavior (NPP additions) |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L589 | `MRK:NAVPP_CLEAN` | NEXT-file clean procedure |
| `nav-orc/skills/nav_project_proc/SKILL.md` | L601 | `MRK:NAVPP_PERMS` | Permissions |
| `nav-orc/spec/nav-v1-spec.md` | L53 | `MRK:NAVSPEC_CHANGELOG` | Changelog |
| `nav-orc/spec/nav-v1-spec.md` | L116 | `MRK:NAVSPEC_PRINCIPLES` | Highest-priority principles |
| `nav-orc/spec/nav-v1-spec.md` | L157 | `MRK:NAVSPEC_DELIVERY` | Delivery scope and boundaries |
| `nav-orc/spec/nav-v1-spec.md` | L196 | `MRK:NAVSPEC_PURPOSE` | Purpose |
| `nav-orc/spec/nav-v1-spec.md` | L211 | `MRK:NAVSPEC_CORE` | Core concept |
| `nav-orc/spec/nav-v1-spec.md` | L226 | `MRK:NAVSPEC_L1_L2` | NAV header |
| `nav-orc/spec/nav-v1-spec.md` | L256 | `MRK:NAVSPEC_MRK_LINE` | MRK line schema |
| `nav-orc/spec/nav-v1-spec.md` | L283 | `MRK:NAVSPEC_NAMESPACE` | Tag namespacing |
| `nav-orc/spec/nav-v1-spec.md` | L304 | `MRK:NAVSPEC_GRANULARITY` | Granularity — what to MRK |
| `nav-orc/spec/nav-v1-spec.md` | L316 | `MRK:NAVSPEC_LARGE` | Two-tier NAV for large files |
| `nav-orc/spec/nav-v1-spec.md` | L328 | `MRK:NAVSPEC_FETCH` | Precise line-range fetch |
| `nav-orc/spec/nav-v1-spec.md` | L338 | `MRK:NAVSPEC_INTEGRITY` | Hash-based integrity |
| `nav-orc/spec/nav-v1-spec.md` | L352 | `MRK:NAVSPEC_STALENESS` | Freshness marker |
| `nav-orc/spec/nav-v1-spec.md` | L364 | `MRK:NAVSPEC_SENSITIVITY` | Sensitivity labels |
| `nav-orc/spec/nav-v1-spec.md` | L418 | `MRK:NAVSPEC_FILE_CREATE` | File creation rule |
| `nav-orc/spec/nav-v1-spec.md` | L441 | `MRK:NAVSPEC_NAV_RULE` | NAV-RULE — tokens, alerts, placement |
| `nav-orc/spec/nav-v1-spec.md` | L552 | `MRK:NAVSPEC_INDEX_HIERARCHY` | Three-tier index architecture |
| `nav-orc/spec/nav-v1-spec.md` | L648 | `MRK:NAVSPEC_SHIPPING_STATE` | Dev state vs ship state, L2 swap mechanics |
| `nav-orc/spec/nav-v1-spec.md` | L704 | `MRK:NAVSPEC_DIRECTORIES` | Directory conventions |
| `nav-orc/spec/nav-v1-spec.md` | L787 | `MRK:NAVSPEC_RULES` | Access rules enforcement |
| `nav-orc/spec/nav-v1-spec.md` | L809 | `MRK:NAVSPEC_REINDEX` | Reindex tool responsibilities |
| `nav-orc/spec/nav-v1-spec.md` | L848 | `MRK:NAVSPEC_COMMIT` | Commit routine + same-commit |
| `nav-orc/spec/nav-v1-spec.md` | L903 | `MRK:NAVSPEC_MISS_TAXONOMY` | Miss-tracking taxonomy |
| `nav-orc/spec/nav-v1-spec.md` | L936 | `MRK:NAVSPEC_IO_ACCOUNTING` | I/O accounting R/W/saved |
| `nav-orc/spec/nav-v1-spec.md` | L991 | `MRK:NAVSPEC_DEBUG` | Debug mode + MRK path manifest |
| `nav-orc/spec/nav-v1-spec.md` | L1037 | `MRK:NAVSPEC_DRAFT_MODE` | Draft mode |
| `nav-orc/spec/nav-v1-spec.md` | L1073 | `MRK:NAVSPEC_PROJECT_WORKFLOW` | /nav project workflow |
| `nav-orc/spec/nav-v1-spec.md` | L1146 | `MRK:NAVSPEC_MODULAR_LOAD` | Modular context load |
| `nav-orc/spec/nav-v1-spec.md` | L1252 | `MRK:NAVSPEC_ORCA_FINGERPRINT` | ORCa organizational fingerprint |
| `nav-orc/spec/nav-v1-spec.md` | L1305 | `MRK:NAVSPEC_FOCUS_ON_WORK` | Focus-on-work rule |
| `nav-orc/spec/nav-v1-spec.md` | L1337 | `MRK:NAVSPEC_STATS` | Optional .nav-stats |
| `nav-orc/spec/nav-v1-spec.md` | L1349 | `MRK:NAVSPEC_SKILL` | Skill pair reference |
| `nav-orc/spec/nav-v1-spec.md` | L1375 | `MRK:NAVSPEC_PROFILE_REF` | Profile spec reference |
| `nav-orc/spec/nav-v1-spec.md` | L1391 | `MRK:NAVSPEC_V2_BOUNDARY` | v2 out-of-scope statement |
| `nav-orc/spec/nav-v1-spec.md` | L1418 | `MRK:NAVSPEC_USECASES` | Use cases |
| `nav-orc/spec/nav-v1-spec.md` | L1434 | `MRK:NAVSPEC_META` | Meta — version, history |
| `nav-orc/tools/README.md` | L11 | `MRK:TOOLS_README_PROTOCOL` | Access protocol (P1 v3) |
| `nav-orc/tools/README.md` | L18 | `MRK:TOOLS_README_RULES` | Hard rules (P2 v2) |
| `nav-orc/tools/README.md` | L27 | `MRK:TOOLS_README_CONFLICT` | Conflict-resolution |
| `nav-orc/tools/README.md` | L35 | `MRK:TOOLS_README_CUSTOM` | Custom context (preserved) |
| `nav-orc/tools/orc-nav-reindex.py` | L64 | `MRK:REINDEX_CONSTANTS` | Module constants and configuration |
| `nav-orc/tools/orc-nav-reindex.py` | L127 | `MRK:REINDEX_DETECT` | File type detection |
| `nav-orc/tools/orc-nav-reindex.py` | L143 | `MRK:REINDEX_PARSE` | Anchor and TOC parsing |
| `nav-orc/tools/orc-nav-reindex.py` | L243 | `MRK:REINDEX_STRIP` | Legacy format stripping |
| `nav-orc/tools/orc-nav-reindex.py` | L412 | `MRK:REINDEX_EMIT` | Output generation helpers |
| `nav-orc/tools/orc-nav-reindex.py` | L532 | `MRK:REINDEX_MIGRATE` | Core migration and reindex engine |
| `nav-orc/tools/orc-nav-reindex.py` | L810 | `MRK:REINDEX_CLI` | Scope configuration and file collection |
| `nav-orc/tools/orc-nav-reindex.py` | L908 | `MRK:REINDEX_CMDS` | Migrate, verify, reindex subcommands |
| `nav-orc/tools/orc-nav-reindex.py` | L1007 | `MRK:REINDEX_INDEX_HELPERS` | Index generation helpers |
| `nav-orc/tools/orc-nav-reindex.py` | L1327 | `MRK:REINDEX_CMD_INDEX` | Index subcommand |
| `nav-orc/tools/orc-nav-reindex.py` | L1473 | `MRK:REINDEX_CMD_APPEND` | Append subcommand |
| `nav-orc/tools/orc-nav-reindex.py` | L1598 | `MRK:REINDEX_CMD_MAIN_INDEX` | main-index subcommand: hierarchical MAIN-INDEX + dirname-indexes |
| `nav-orc/tools/orc-nav-reindex.py` | L1645 | `MRK:REINDEX_MAIN` | Entry point and subcommand dispatch |
| `nav-orc/tools/pt-orc-reindex.ps1` | L19 | `MRK:REINDEX_PS1_SETUP` | Setup: find Python tool + resolver |
| `nav-orc/tools/pt-orc-reindex.ps1` | L40 | `MRK:REINDEX_PS1_DISPATCH` | Flag dispatch |
| `nav-orc/tools/pt-orc-reindex.sh` | L19 | `MRK:REINDEX_SH_SETUP` | Setup: find Python tool + resolver |
| `nav-orc/tools/pt-orc-reindex.sh` | L40 | `MRK:REINDEX_SH_DISPATCH` | Flag dispatch |
| `nav-orc/tools/tools-index.md` | L8 | `MRK:TOOLS_INDEX_FILES` | Files in this directory |
| `pt-orc/correlations/correlations-index.md` | L8 | `MRK:CORRELATIONS_INDEX_FILES` | Files in this directory |
| `pt-orc/docs/README.md` | L11 | `MRK:DOCS_README_PROTOCOL` | Access protocol (P1 v3) |
| `pt-orc/docs/README.md` | L18 | `MRK:DOCS_README_RULES` | Hard rules (P2 v2) |
| `pt-orc/docs/README.md` | L27 | `MRK:DOCS_README_CONFLICT` | Conflict-resolution |
| `pt-orc/docs/README.md` | L35 | `MRK:DOCS_README_CUSTOM` | Custom context (preserved) |
| `pt-orc/docs/design.md` | L14 | `MRK:PATTERNS` | Shared Patterns |
| `pt-orc/docs/design.md` | L62 | `MRK:GOTCHAS` | Key Design Decisions and Gotchas |
| `pt-orc/docs/design.md` | L101 | `MRK:D03` | 03_comp_scan.sh Architecture |
| `pt-orc/docs/design.md` | L168 | `MRK:TOOLS` | Tool Dependencies |
| `pt-orc/docs/docs-index.md` | L8 | `MRK:DOCS_INDEX_FILES` | Files in this directory |
| `pt-orc/docs/funcs.md` | L16 | `MRK:CTX` | §0. Context |
| `pt-orc/docs/funcs.md` | L32 | `MRK:S00` | 00_pt-orc.sh |
| `pt-orc/docs/funcs.md` | L51 | `MRK:S01` | 01_dns_recon_v0.76.sh |
| `pt-orc/docs/funcs.md` | L85 | `MRK:S03` | 03_comp_scan.sh |
| `pt-orc/docs/funcs.md` | L201 | `MRK:S04` | 04_tls_scan_v0.76.sh |
| `pt-orc/docs/funcs.md` | L226 | `MRK:S05` | 05_web_enum_v0.76.sh |
| `pt-orc/docs/funcs.md` | L260 | `MRK:S02` | 02_ip_range_analysis_v0.76.sh |
| `pt-orc/docs/funcs.md` | L282 | `MRK:S06` | 06_wpscan_v0.76.sh |
| `pt-orc/docs/funcs.md` | L307 | `MRK:S07` | 07_service_verify_v0.762.sh |
| `pt-orc/docs/ops.md` | L17 | `MRK:OPS_SCRIPTS` | Scripts at a Glance |
| `pt-orc/docs/ops.md` | L47 | `MRK:OPS_PIPELINE` | Pipeline |
| `pt-orc/docs/ops.md` | L134 | `MRK:OPS_FLAGS` | CLI Flags |
| `pt-orc/docs/ops.md` | L222 | `MRK:OPS_OPERATIONS` | Common Operations |
| `pt-orc/docs/ops.md` | L287 | `MRK:OPS_DIRS` | Directory Structure |
| `pt-orc/docs/orientation.md` | L16 | `MRK:IDX_S0` | §0. MRK Naming Convention |
| `pt-orc/docs/orientation.md` | L44 | `MRK:IDX_S1` | §1. Suite Overview |
| `pt-orc/docs/orientation.md` | L64 | `MRK:IDX_S2` | §2. Data Flow |
| `pt-orc/docs/orientation.md` | L83 | `MRK:IDX_S3` | §3. Engagement Config |
| `pt-orc/docs/orientation.md` | L150 | `MRK:IDX_S4` | §4. Evidence Directory Layout |
| `pt-orc/docs/orientation.md` | L242 | `MRK:IDX_S5` | §5. Stealth Tier Reference |
| `pt-orc/docs/skill-brief.md` | L29 | `MRK:SKL_HOWTO` | How to Use This File |
| `pt-orc/docs/skill-brief.md` | L33 | `MRK:SKL_S0` | §0. Skill Navigation Protocol — how the skill reads suite files efficiently |
| `pt-orc/docs/skill-brief.md` | L115 | `MRK:SKL_S1` | §1. Skill Role |
| `pt-orc/docs/skill-brief.md` | L135 | `MRK:SKL_S2` | §2. Reference File Loading Strategy |
| `pt-orc/docs/skill-brief.md` | L148 | `MRK:SKL_S3` | §3. State Snapshot Schema |
| `pt-orc/docs/skill-brief.md` | L220 | `MRK:SKL_S4` | §4. Phase → Skill Dispatch |
| `pt-orc/docs/skill-brief.md` | L239 | `MRK:SKL_S5` | §5. Evidence Consumption Map |
| `pt-orc/docs/skill-brief.md` | L304 | `MRK:SKL_S6` | §6. Finding Severity Assignment |
| `pt-orc/docs/skill-brief.md` | L325 | `MRK:SKL_S7` | §7. Hard Limits |
| `pt-orc/docs/skill-brief.md` | L338 | `MRK:SKL_S8` | §8. Skill Version Tracking |
| `pt-orc/docs/skill-brief.md` | L354 | `MRK:SKL_S9` | §9. Session Start Checklist for Skill Builder |
| `pt-orc/docs/skill-brief.md` | L369 | `MRK:SKL_S10` | §10. Multi-analyst + shared-Claude broker awareness |
| `pt-orc/docs/skill-brief.md` | L403 | `MRK:SKL_S11` | §11. Cross-engagement correlation + finding-ID namespace |
| `pt-orc/docs/skill-brief.md` | L441 | `MRK:SKL_S12` | §12. NAV-RULE + Notes protocol integration |
| `pt-orc/docs/skill-brief.md` | L478 | `MRK:SKL_S13` | §13. Planning artefacts (`.in/`, `.deleted/`, `NEXT.md`, `techguard-workplan.md`) |
| `pt-orc/modules/modules-index.md` | L8 | `MRK:MODULES_INDEX_FILES` | Files in this directory |
| `pt-orc/scripts/00_pt-orc.sh` | L61 | `MRK:00_ROOT` | ROOT CHECK |
| `pt-orc/scripts/00_pt-orc.sh` | L71 | `MRK:00_CONF` | ENGAGEMENT CONFIG |
| `pt-orc/scripts/00_pt-orc.sh` | L79 | `MRK:00_LOG` | COLOURS AND LOGGING + STEP BANNER |
| `pt-orc/scripts/00_pt-orc.sh` | L109 | `MRK:00_DEFAULTS` | DEFAULTS + STEP STATUS ACCUMULATORS |
| `pt-orc/scripts/00_pt-orc.sh` | L139 | `MRK:00_USAGE` | USAGE BANNER |
| `pt-orc/scripts/00_pt-orc.sh` | L188 | `MRK:00_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/00_pt-orc.sh` | L216 | `MRK:00_DISCOVER` | SCRIPT DISCOVERY |
| `pt-orc/scripts/00_pt-orc.sh` | L246 | `MRK:00_CONTROL` | STEP CONTROL |
| `pt-orc/scripts/00_pt-orc.sh` | L266 | `MRK:00_RUNNER` | STEP RUNNER |
| `pt-orc/scripts/00_pt-orc.sh` | L309 | `MRK:00_SUMMARY` | SUMMARY TABLE |
| `pt-orc/scripts/00_pt-orc.sh` | L372 | `MRK:00_MAIN` | MAIN |
| `pt-orc/scripts/01_dns_recon.sh` | L47 | `MRK:01_ROOT` | ROOT CHECK |
| `pt-orc/scripts/01_dns_recon.sh` | L57 | `MRK:01_CONF` | ENGAGEMENT CONFIGURATION |
| `pt-orc/scripts/01_dns_recon.sh` | L102 | `MRK:01_LOG` | COLOURS AND LOGGING |
| `pt-orc/scripts/01_dns_recon.sh` | L129 | `MRK:01_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/01_dns_recon.sh` | L149 | `MRK:01_SRCIP` | SOURCE IP VERIFICATION |
| `pt-orc/scripts/01_dns_recon.sh` | L170 | `MRK:01_CONFIRM` | SCOPE CONFIRMATION |
| `pt-orc/scripts/01_dns_recon.sh` | L203 | `MRK:01_SCOPE` | THIRD-PARTY / PRIVATE IP BOUNDARY CHECKS + add_ip accumulator |
| `pt-orc/scripts/01_dns_recon.sh` | L241 | `MRK:01_TAKEOVER` | SUBDOMAIN TAKEOVER DETECTION |
| `pt-orc/scripts/01_dns_recon.sh` | L263 | `MRK:01_STATE` | TARGET ACCUMULATORS |
| `pt-orc/scripts/01_dns_recon.sh` | L289 | `MRK:01_PASSIVE` | PASSIVE RECON |
| `pt-orc/scripts/01_dns_recon.sh` | L420 | `MRK:01_ACTIVE` | ACTIVE DNS |
| `pt-orc/scripts/01_dns_recon.sh` | L473 | `MRK:01_RESOLVE` | RESOLUTION AND LIVE CHECK |
| `pt-orc/scripts/01_dns_recon.sh` | L537 | `MRK:01_OUTPUT` | TARGET LIST + SUMMARY |
| `pt-orc/scripts/01_dns_recon.sh` | L654 | `MRK:01_MAIN` | MAIN entry point |
| `pt-orc/scripts/02_ip_analysis.sh` | L42 | `MRK:02_LOG` | COLOURS AND LOGGING |
| `pt-orc/scripts/02_ip_analysis.sh` | L60 | `MRK:02_CONF` | ENGAGEMENT CONFIGURATION |
| `pt-orc/scripts/02_ip_analysis.sh` | L85 | `MRK:02_USAGE` | USAGE |
| `pt-orc/scripts/02_ip_analysis.sh` | L110 | `MRK:02_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/02_ip_analysis.sh` | L129 | `MRK:02_DEPS` | DEPENDENCY CHECK |
| `pt-orc/scripts/02_ip_analysis.sh` | L167 | `MRK:02_TARGETS` | TARGET LOADING |
| `pt-orc/scripts/02_ip_analysis.sh` | L220 | `MRK:02_CONFIRM` | SCOPE CONFIRMATION |
| `pt-orc/scripts/02_ip_analysis.sh` | L251 | `MRK:02_CMDWRAP` | DRY-RUN COMMAND WRAPPER |
| `pt-orc/scripts/02_ip_analysis.sh` | L268 | `MRK:02_STATE` | PER-IP ACCUMULATORS |
| `pt-orc/scripts/02_ip_analysis.sh` | L282 | `MRK:02_ANALYZE` | PER-IP ANALYSIS |
| `pt-orc/scripts/02_ip_analysis.sh` | L599 | `MRK:02_REPORT` | CONSOLIDATED REPORT |
| `pt-orc/scripts/02_ip_analysis.sh` | L769 | `MRK:02_MAIN` | MAIN entry point |
| `pt-orc/scripts/03_comp_scan.sh` | L65 | `MRK:03_ROOT` | ROOT CHECK |
| `pt-orc/scripts/03_comp_scan.sh` | L75 | `MRK:03_CONF` | ENGAGEMENT CONFIGURATION |
| `pt-orc/scripts/03_comp_scan.sh` | L162 | `MRK:03_TIER` | STEALTH TIER PARAMETERS |
| `pt-orc/scripts/03_comp_scan.sh` | L312 | `MRK:03_LOG` | COLOURS AND LOGGING |
| `pt-orc/scripts/03_comp_scan.sh` | L337 | `MRK:03_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/03_comp_scan.sh` | L379 | `MRK:03_DIRS` | DIRECTORY STRUCTURE SETUP |
| `pt-orc/scripts/03_comp_scan.sh` | L403 | `MRK:03_DB` | MSF / POSTGRES DB HELPERS |
| `pt-orc/scripts/03_comp_scan.sh` | L463 | `MRK:03_SCAN` | SCAN EXECUTION MODEL |
| `pt-orc/scripts/03_comp_scan.sh` | L705 | `MRK:03_CSV` | CSV FALLBACK HELPERS |
| `pt-orc/scripts/03_comp_scan.sh` | L762 | `MRK:03_GNMAP` | GNMAP FALLBACK |
| `pt-orc/scripts/03_comp_scan.sh` | L838 | `MRK:03_SCOPE` | TIER RESOLUTION |
| `pt-orc/scripts/03_comp_scan.sh` | L934 | `MRK:03_SRCIP` | SOURCE IP VERIFICATION (PTE) |
| `pt-orc/scripts/03_comp_scan.sh` | L956 | `MRK:03_CONFIRM` | SCOPE CONFIRMATION |
| `pt-orc/scripts/03_comp_scan.sh` | L990 | `MRK:03_RATE` | RATE SELF-TEST (PTE / evasion mode) |
| `pt-orc/scripts/03_comp_scan.sh` | L1024 | `MRK:03_WS` | MSF WORKSPACE SETUP |
| `pt-orc/scripts/03_comp_scan.sh` | L1112 | `MRK:03_EXCL` | TESTER EXCLUSION |
| `pt-orc/scripts/03_comp_scan.sh` | L1416 | `MRK:03_P1` | PHASE 1: DISCOVERY |
| `pt-orc/scripts/03_comp_scan.sh` | L1450 | `MRK:03_P2` | PHASE 2: TCP FULL SCAN |
| `pt-orc/scripts/03_comp_scan.sh` | L1797 | `MRK:03_NSE` | PHASE 2b: COMMON-PORT NSE SWEEP |
| `pt-orc/scripts/03_comp_scan.sh` | L1891 | `MRK:03_OS` | PHASE 2c: OS FINGERPRINTING |
| `pt-orc/scripts/03_comp_scan.sh` | L2025 | `MRK:03_P3` | PHASE 3: UDP CORRELATION SCAN |
| `pt-orc/scripts/03_comp_scan.sh` | L2121 | `MRK:03_P4` | PHASE 4: SERVICE ENUMERATION |
| `pt-orc/scripts/03_comp_scan.sh` | L2127 | `MRK:03_PROBES` | Active service probes |
| `pt-orc/scripts/03_comp_scan.sh` | L2462 | `MRK:03_P4B` | PHASE 4b: PTE SERVICE ENUMERATION |
| `pt-orc/scripts/03_comp_scan.sh` | L2628 | `MRK:03_P5` | PHASE 5: REPORT / SUMMARY |
| `pt-orc/scripts/03_comp_scan.sh` | L2699 | `MRK:03_MAIN` | MAIN |
| `pt-orc/scripts/04_tls_scan.sh` | L46 | `MRK:04_ROOT` | ROOT CHECK |
| `pt-orc/scripts/04_tls_scan.sh` | L56 | `MRK:04_CONF` | ENGAGEMENT CONFIGURATION |
| `pt-orc/scripts/04_tls_scan.sh` | L84 | `MRK:04_LOG` | COLOURS AND LOGGING |
| `pt-orc/scripts/04_tls_scan.sh` | L110 | `MRK:04_DB` | MSF DB CREDENTIALS |
| `pt-orc/scripts/04_tls_scan.sh` | L132 | `MRK:04_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/04_tls_scan.sh` | L151 | `MRK:04_SCAN` | SCAN EXECUTION MODEL |
| `pt-orc/scripts/04_tls_scan.sh` | L220 | `MRK:04_CONFIRM` | SCOPE CONFIRMATION |
| `pt-orc/scripts/04_tls_scan.sh` | L246 | `MRK:04_TARGETS` | TARGET LIST ASSEMBLY |
| `pt-orc/scripts/04_tls_scan.sh` | L279 | `MRK:04_ASSESS` | PER-HOST TLS ASSESSMENT |
| `pt-orc/scripts/04_tls_scan.sh` | L480 | `MRK:04_SCREENS` | SCREENSHOT CAPTURE |
| `pt-orc/scripts/04_tls_scan.sh` | L500 | `MRK:04_MAIN` | MAIN entry point |
| `pt-orc/scripts/05_web_enum.sh` | L52 | `MRK:05_ROOT` | ROOT CHECK |
| `pt-orc/scripts/05_web_enum.sh` | L62 | `MRK:05_CONF` | ENGAGEMENT CONFIGURATION |
| `pt-orc/scripts/05_web_enum.sh` | L107 | `MRK:05_LOG` | COLOURS AND LOGGING |
| `pt-orc/scripts/05_web_enum.sh` | L132 | `MRK:05_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/05_web_enum.sh` | L154 | `MRK:05_DB` | MSF DB HELPERS |
| `pt-orc/scripts/05_web_enum.sh` | L224 | `MRK:05_SCAN` | SCAN EXECUTION MODEL |
| `pt-orc/scripts/05_web_enum.sh` | L294 | `MRK:05_CONFIRM` | SCOPE CONFIRMATION |
| `pt-orc/scripts/05_web_enum.sh` | L321 | `MRK:05_TARGETS` | TARGET ASSEMBLY |
| `pt-orc/scripts/05_web_enum.sh` | L361 | `MRK:05_TLS` | TLS DETECTION |
| `pt-orc/scripts/05_web_enum.sh` | L379 | `MRK:05_ENUM` | PER-HOST WEB ENUMERATION |
| `pt-orc/scripts/05_web_enum.sh` | L669 | `MRK:05_MAIN` | MAIN entry point |
| `pt-orc/scripts/06_wpscan.sh` | L45 | `MRK:06_LOG` | COLOURS AND LOGGING |
| `pt-orc/scripts/06_wpscan.sh` | L63 | `MRK:06_CONF` | ENGAGEMENT CONFIGURATION |
| `pt-orc/scripts/06_wpscan.sh` | L106 | `MRK:06_USAGE` | USAGE |
| `pt-orc/scripts/06_wpscan.sh` | L136 | `MRK:06_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/06_wpscan.sh` | L158 | `MRK:06_DEPS` | DEPENDENCY CHECK |
| `pt-orc/scripts/06_wpscan.sh` | L190 | `MRK:06_DETECT` | PHASE 1 WP DETECTION SWEEP |
| `pt-orc/scripts/06_wpscan.sh` | L299 | `MRK:06_LOAD` | PHASE 2 TARGET LOADING |
| `pt-orc/scripts/06_wpscan.sh` | L329 | `MRK:06_CONFIRM` | SCOPE CONFIRMATION |
| `pt-orc/scripts/06_wpscan.sh` | L363 | `MRK:06_HELP` | HELPERS |
| `pt-orc/scripts/06_wpscan.sh` | L381 | `MRK:06_STATE` | PER-TARGET ACCUMULATORS |
| `pt-orc/scripts/06_wpscan.sh` | L397 | `MRK:06_ASSESS` | PER-TARGET ASSESSMENT |
| `pt-orc/scripts/06_wpscan.sh` | L756 | `MRK:06_REPORT` | CONSOLIDATED REPORT |
| `pt-orc/scripts/06_wpscan.sh` | L924 | `MRK:06_MAIN` | MAIN entry point |
| `pt-orc/scripts/07_service_verify.sh` | L69 | `MRK:07_ROOT` | ROOT CHECK |
| `pt-orc/scripts/07_service_verify.sh` | L79 | `MRK:07_CONF` | ENGAGEMENT CONFIGURATION |
| `pt-orc/scripts/07_service_verify.sh` | L120 | `MRK:07_LOG` | COLOURS AND LOGGING |
| `pt-orc/scripts/07_service_verify.sh` | L142 | `MRK:07_ARGS` | ARGUMENT PARSING |
| `pt-orc/scripts/07_service_verify.sh` | L167 | `MRK:07_DB` | MSF DB + MODULE RUNNER |
| `pt-orc/scripts/07_service_verify.sh` | L232 | `MRK:07_RESULTS` | RESULT TRACKING  "STATUS |
| `pt-orc/scripts/07_service_verify.sh` | L250 | `MRK:07_PARSE` | INPUT PARSING |
| `pt-orc/scripts/07_service_verify.sh` | L530 | `MRK:07_TOOLS` | TOOL AVAILABILITY |
| `pt-orc/scripts/07_service_verify.sh` | L555 | `MRK:07_DIR` | EVIDENCE DIR HELPER |
| `pt-orc/scripts/07_service_verify.sh` | L567 | `MRK:07_P_REDIS` | PROBE: REDIS NOAUTH |
| `pt-orc/scripts/07_service_verify.sh` | L632 | `MRK:07_P_MYSQL` | PROBE: MYSQL NOAUTH / ANONYMOUS LOGIN |
| `pt-orc/scripts/07_service_verify.sh` | L687 | `MRK:07_P_PG` | PROBE: POSTGRESQL NOAUTH |
| `pt-orc/scripts/07_service_verify.sh` | L752 | `MRK:07_P_MONGO` | PROBE: MONGODB NOAUTH |
| `pt-orc/scripts/07_service_verify.sh` | L812 | `MRK:07_P_SSH` | PROBE: SSH VERSION |
| `pt-orc/scripts/07_service_verify.sh` | L914 | `MRK:07_P_FTP` | PROBE: FTP ANONYMOUS LOGIN |
| `pt-orc/scripts/07_service_verify.sh` | L980 | `MRK:07_P_SMB` | PROBE: SMB NULL SESSION (PTI) |
| `pt-orc/scripts/07_service_verify.sh` | L1032 | `MRK:07_P_SNMP` | PROBE: SNMP DEFAULT COMMUNITY |
| `pt-orc/scripts/07_service_verify.sh` | L1088 | `MRK:07_P_SMTP` | PROBE: SMTP OPEN RELAY |
| `pt-orc/scripts/07_service_verify.sh` | L1149 | `MRK:07_P_SSRF` | PROBE: SSRF → IMDS (PTE) |
| `pt-orc/scripts/07_service_verify.sh` | L1224 | `MRK:07_P_TLS` | PROBE: TLS CERT VALIDITY |
| `pt-orc/scripts/07_service_verify.sh` | L1290 | `MRK:07_P_WEBH` | PROBE: HTTP SECURITY HEADERS |
| `pt-orc/scripts/07_service_verify.sh` | L1338 | `MRK:07_ENUM` | POST-VULN ENUMERATION |
| `pt-orc/scripts/07_service_verify.sh` | L1510 | `MRK:07_P_MSSQL` | PROBE: MSSQL |
| `pt-orc/scripts/07_service_verify.sh` | L1557 | `MRK:07_P_NFS` | PROBE: NFS |
| `pt-orc/scripts/07_service_verify.sh` | L1596 | `MRK:07_P_TELNET` | PROBE: Telnet |
| `pt-orc/scripts/07_service_verify.sh` | L1627 | `MRK:07_P_IPMI` | PROBE: IPMI |
| `pt-orc/scripts/07_service_verify.sh` | L1676 | `MRK:07_P_RDP` | PROBE: RDP |
| `pt-orc/scripts/07_service_verify.sh` | L1714 | `MRK:07_P_WINRM` | PROBE: WinRM |
| `pt-orc/scripts/07_service_verify.sh` | L1759 | `MRK:07_P_WEBGEN` | PROBE: Web generic |
| `pt-orc/scripts/07_service_verify.sh` | L1843 | `MRK:07_INGEST` | PHASE 0 INGEST STUBS |
| `pt-orc/scripts/07_service_verify.sh` | L1924 | `MRK:07_DISPATCH` | PROBE DISPATCHER |
| `pt-orc/scripts/07_service_verify.sh` | L2017 | `MRK:07_REPORT` | REPORT WRITER |
| `pt-orc/scripts/07_service_verify.sh` | L2125 | `MRK:07_CONFIRM` | SCOPE CONFIRMATION |
| `pt-orc/scripts/07_service_verify.sh` | L2153 | `MRK:07_MAIN` | MAIN entry point |
| `pt-orc/scripts/README.md` | L11 | `MRK:SCRIPTS_README_PROTOCOL` | Access protocol (P1 v3) |
| `pt-orc/scripts/README.md` | L18 | `MRK:SCRIPTS_README_RULES` | Hard rules (P2 v2) |
| `pt-orc/scripts/README.md` | L27 | `MRK:SCRIPTS_README_CONFLICT` | Conflict-resolution |
| `pt-orc/scripts/README.md` | L35 | `MRK:SCRIPTS_README_CUSTOM` | Custom context (preserved) |
| `pt-orc/scripts/orc-common-lib.sh` | L54 | `MRK:COM_DB` | MSF / POSTGRES DIRECT ACCESS |
| `pt-orc/scripts/orc-common-lib.sh` | L180 | `MRK:COM_TRAIL` | MSF NOTES WRITER |
| `pt-orc/scripts/orc-common-lib.sh` | L388 | `MRK:COM_BANNER` | standalone banner |
| `pt-orc/scripts/orc-common-lib.sh` | L455 | `MRK:COM_SELFTEST` | reserved for future --test mode |
| `pt-orc/scripts/scripts-index.md` | L8 | `MRK:SCRIPTS_INDEX_FILES` | Files in this directory |
| `pt-orc/skills/pt-commands/SKILL.md` | L43 | `MRK:PT_CMDS_PASSIVE_CAPTURE` | GROUP: PASSIVE / CAPTURE |
| `pt-orc/skills/pt-commands/SKILL.md` | L69 | `MRK:PT_CMDS_DNS_OSINT` | GROUP: DNS / OSINT |
| `pt-orc/skills/pt-commands/SKILL.md` | L140 | `MRK:PT_CMDS_SWEEP` | GROUP: SWEEP |
| `pt-orc/skills/pt-commands/SKILL.md` | L199 | `MRK:PT_CMDS_SMB` | GROUP: SMB |
| `pt-orc/skills/pt-commands/SKILL.md` | L229 | `MRK:PT_CMDS_NFS` | GROUP: NFS |
| `pt-orc/skills/pt-commands/SKILL.md` | L257 | `MRK:PT_CMDS_SNMP` | GROUP: SNMP |
| `pt-orc/skills/pt-commands/SKILL.md` | L287 | `MRK:PT_CMDS_FTP` | GROUP: FTP |
| `pt-orc/skills/pt-commands/SKILL.md` | L323 | `MRK:PT_CMDS_TLS` | GROUP: TLS |
| `pt-orc/skills/pt-commands/SKILL.md` | L357 | `MRK:PT_CMDS_HTTP` | GROUP: HTTP |
| `pt-orc/skills/pt-commands/SKILL.md` | L402 | `MRK:PT_CMDS_WP` | GROUP: WP |
| `pt-orc/skills/pt-commands/SKILL.md` | L459 | `MRK:PT_CMDS_SSH` | GROUP: SSH |
| `pt-orc/skills/pt-commands/SKILL.md` | L481 | `MRK:PT_CMDS_RDP` | GROUP: RDP |
| `pt-orc/skills/pt-commands/SKILL.md` | L500 | `MRK:PT_CMDS_TELNET` | GROUP: TELNET |
| `pt-orc/skills/pt-commands/SKILL.md` | L516 | `MRK:PT_CMDS_OOB` | GROUP: OOB (IPMI / iLO / iDRAC) |
| `pt-orc/skills/pt-commands/SKILL.md` | L539 | `MRK:PT_CMDS_LDAP` | GROUP: LDAP |
| `pt-orc/skills/pt-commands/SKILL.md` | L563 | `MRK:PT_CMDS_DB` | GROUP: DB (databases) |
| `pt-orc/skills/pt-commands/SKILL.md` | L591 | `MRK:PT_CMDS_VPN` | GROUP: VPN |
| `pt-orc/skills/pt-commands/SKILL.md` | L623 | `MRK:PT_CMDS_NETDEV` | GROUP: NETDEV |
| `pt-orc/skills/pt-commands/SKILL.md` | L646 | `MRK:PT_CMDS_MQTT` | GROUP: MQTT |
| `pt-orc/skills/pt-commands/SKILL.md` | L670 | `MRK:PT_CMDS_MSF_REFERENCE` | MSF Quick Reference |
| `pt-orc/skills/pt-commands/SKILL.md` | L700 | `MRK:PT_CMDS_MANUAL_LOG` | Manual Session Log Header |
| `pt-orc/skills/pt-enum/SKILL.md` | L30 | `MRK:PT_ENUM_RECEIVED` | Received from L1 (pt-orc) |
| `pt-orc/skills/pt-enum/SKILL.md` | L43 | `MRK:PT_ENUM_EXIT` | Exit Criteria |
| `pt-orc/skills/pt-enum/SKILL.md` | L55 | `MRK:PT_ENUM_DISPATCH` | L3 Dispatch Table |
| `pt-orc/skills/pt-enum/SKILL.md` | L105 | `MRK:PT_ENUM_APPROACH` | Enumeration Approach by Stage |
| `pt-orc/skills/pt-enum/SKILL.md` | L166 | `MRK:PT_ENUM_STUB_SCHEMA` | Finding Stub Schema |
| `pt-orc/skills/pt-enum/SKILL.md` | L205 | `MRK:PT_ENUM_RETURN` | Return Pass Behaviour |
| `pt-orc/skills/pt-enum/SKILL.md` | L216 | `MRK:PT_ENUM_OUTPUT` | Output — Enum Summary Block |
| `pt-orc/skills/pt-evidence/SKILL.md` | L27 | `MRK:PT_EVIDENCE_RECEIVED` | Received from L1 (pt-orc) |
| `pt-orc/skills/pt-evidence/SKILL.md` | L38 | `MRK:PT_EVIDENCE_EXIT` | Exit Criteria |
| `pt-orc/skills/pt-evidence/SKILL.md` | L48 | `MRK:PT_EVIDENCE_PIPELINE` | Processing Pipeline |
| `pt-orc/skills/pt-evidence/SKILL.md` | L155 | `MRK:PT_EVIDENCE_TOOL_GUIDE` | Tool Output Interpretation Guide |
| `pt-orc/skills/pt-evidence/SKILL.md` | L226 | `MRK:PT_EVIDENCE_OUTPUT` | Output — Evidence Processing Block |
| `pt-orc/skills/pt-monitor/SKILL.md` | L26 | `MRK:MON_ACTIVATE` | Activate when |
| `pt-orc/skills/pt-monitor/SKILL.md` | L34 | `MRK:MON_FIRSTREAD` | First read |
| `pt-orc/skills/pt-monitor/SKILL.md` | L46 | `MRK:MON_CORELOOP` | Core loop |
| `pt-orc/skills/pt-monitor/SKILL.md` | L54 | `MRK:MON_CADENCE` | /loop cadence |
| `pt-orc/skills/pt-monitor/SKILL.md` | L62 | `MRK:MON_ANOMALY` | Anomaly discipline |
| `pt-orc/skills/pt-monitor/SKILL.md` | L73 | `MRK:MON_DEBRIEF` | Debrief protocol |
| `pt-orc/skills/pt-monitor/SKILL.md` | L87 | `MRK:MON_ORCNAV` | Integration with /orc-nav |
| `pt-orc/skills/pt-monitor/SKILL.md` | L116 | `MRK:MON_DONT` | Don't |
| `pt-orc/skills/pt-monitor/SKILL.md` | L127 | `MRK:MON_PERMS` | Permissions |
| `pt-orc/skills/pt-monitor/SKILL.md` | L149 | `MRK:MON_INSTALL` | Install as user-global skill (optional) |
| `pt-orc/skills/pt-orc/SKILL.md` | L38 | `MRK:PTORC_ROLE` | Role |
| `pt-orc/skills/pt-orc/SKILL.md` | L49 | `MRK:PTORC_PRINCIPLES` | Core Principles (Immutable) |
| `pt-orc/skills/pt-orc/SKILL.md` | L62 | `MRK:PTORC_NAMING` | Engagement Naming |
| `pt-orc/skills/pt-orc/SKILL.md` | L73 | `MRK:PTORC_DIRS` | Directory Structure |
| `pt-orc/skills/pt-orc/SKILL.md` | L137 | `MRK:PTORC_STAGES` | Stage Registry |
| `pt-orc/skills/pt-orc/SKILL.md` | L157 | `MRK:PTORC_DISPATCH` | Dispatch Table — L2 Skills |
| `pt-orc/skills/pt-orc/SKILL.md` | L179 | `MRK:PTORC_RETURNPASS` | Return Pass Protocol |
| `pt-orc/skills/pt-orc/SKILL.md` | L197 | `MRK:PTORC_STATE` | State Snapshot — Schema |
| `pt-orc/skills/pt-orc/SKILL.md` | L387 | `MRK:PTORC_SESSIONSTART` | Session Start Protocol |
| `pt-orc/skills/pt-orc/SKILL.md` | L394 | `MRK:PTORC_SESSIONEND` | Session End Protocol |
| `pt-orc/skills/pt-orc/SKILL.md` | L403 | `MRK:PTORC_CHECKLISTS` | Checklists |
| `pt-orc/skills/pt-orc/SKILL.md` | L444 | `MRK:PTORC_PITFALLS` | Common Pitfalls |
| `pt-orc/skills/pt-recon/SKILL.md` | L28 | `MRK:PT_RECON_RECEIVED` | Received from L1 (pt-orc) |
| `pt-orc/skills/pt-recon/SKILL.md` | L39 | `MRK:PT_RECON_EXIT` | Exit Criteria |
| `pt-orc/skills/pt-recon/SKILL.md` | L49 | `MRK:PT_RECON_S1` | S1 — Passive Reconnaissance |
| `pt-orc/skills/pt-recon/SKILL.md` | L114 | `MRK:PT_RECON_S2` | S2 — Broad Sweep / Surface Mapping |
| `pt-orc/skills/pt-recon/SKILL.md` | L164 | `MRK:PT_RECON_RETURN` | Return Pass Behaviour |
| `pt-orc/skills/pt-recon/SKILL.md` | L176 | `MRK:PT_RECON_OUTPUT` | Output — Recon Summary Block |
| `pt-orc/skills/pt-report/SKILL.md` | L43 | `MRK:PT_REPORT_RECEIVED` | Received from L1 (pt-orc) |
| `pt-orc/skills/pt-report/SKILL.md` | L55 | `MRK:PT_REPORT_INPUTS` | Input Sources |
| `pt-orc/skills/pt-report/SKILL.md` | L95 | `MRK:PT_REPORT_EXIT` | Exit Criteria |
| `pt-orc/skills/pt-report/SKILL.md` | L104 | `MRK:PT_REPORT_STRUCTURE` | Report Structure (PTI / PTE) |
| `pt-orc/skills/pt-report/SKILL.md` | L151 | `MRK:PT_REPORT_VERSIONING` | Document Versioning |
| `pt-orc/skills/pt-report/SKILL.md` | L167 | `MRK:PT_REPORT_HEADINGS` | PTI Heading Structure |
| `pt-orc/skills/pt-report/SKILL.md` | L187 | `MRK:PT_REPORT_EXEC_SUMMARY` | Executive Summary |
| `pt-orc/skills/pt-report/SKILL.md` | L226 | `MRK:PT_REPORT_BODY_RULES` | Finding Body Writing Rules |
| `pt-orc/skills/pt-report/SKILL.md` | L272 | `MRK:PT_REPORT_OBSERVATIONS` | Observations Writing Rules |
| `pt-orc/skills/pt-report/SKILL.md` | L284 | `MRK:PT_REPORT_IDENTITY` | Device Identity Verification Rule |
| `pt-orc/skills/pt-report/SKILL.md` | L305 | `MRK:PT_REPORT_PENDING` | Pending Actions Pre-Delivery Checklist |
| `pt-orc/skills/pt-report/SKILL.md` | L330 | `MRK:PT_REPORT_SUMMARY_TABLE` | Findings Summary Table |
| `pt-orc/skills/pt-report/SKILL.md` | L345 | `MRK:PT_REPORT_SEVERITY` | Severity Classification |
| `pt-orc/skills/pt-report/SKILL.md` | L367 | `MRK:PT_REPORT_FINDING_TEMPLATE` | Finding Body Template |
| `pt-orc/skills/pt-report/SKILL.md` | L400 | `MRK:PT_REPORT_OBS_TEMPLATE` | Observation Body Template |
| `pt-orc/skills/pt-report/SKILL.md` | L417 | `MRK:PT_REPORT_RETEST` | Re-test Documentation (S8) |
| `pt-orc/skills/pt-report/SKILL.md` | L441 | `MRK:PT_REPORT_SEC1` | Section 1 Introduction Templates |
| `pt-orc/skills/pt-report/SKILL.md` | L487 | `MRK:PT_REPORT_EVIDENCE_INDEX` | Appendix C Evidence Index Template |
| `pt-orc/skills/pt-report/SKILL.md` | L503 | `MRK:PT_REPORT_STYLE` | Style Rules Summary |
| `pt-orc/skills/pt-report/SKILL.md` | L519 | `MRK:PT_REPORT_PITFALLS` | Common Pitfalls |
| `pt-orc/templates/templates-index.md` | L8 | `MRK:TEMPLATES_INDEX_FILES` | Files in this directory |
| `pt-orc/tools/README.md` | L11 | `MRK:TOOLS_README_PROTOCOL` | Access protocol (P1 v3) |
| `pt-orc/tools/README.md` | L18 | `MRK:TOOLS_README_RULES` | Hard rules (P2 v2) |
| `pt-orc/tools/README.md` | L27 | `MRK:TOOLS_README_CONFLICT` | Conflict-resolution |
| `pt-orc/tools/README.md` | L35 | `MRK:TOOLS_README_CUSTOM` | Custom context (preserved) |
| `pt-orc/tools/install-skills.sh` | L28 | `MRK:INSTALL_SKILLS_SETUP` | Setup + arg parsing |
| `pt-orc/tools/install-skills.sh` | L60 | `MRK:INSTALL_SKILLS_SELECTION` | Skill selection (default vs all) |
| `pt-orc/tools/install-skills.sh` | L70 | `MRK:INSTALL_SKILLS_HELPERS` | Hash helpers + counters |
| `pt-orc/tools/install-skills.sh` | L85 | `MRK:INSTALL_SKILLS_MAIN_LOOP` | Main install loop with drift check |
| `pt-orc/tools/install-skills.sh` | L143 | `MRK:INSTALL_SKILLS_SUMMARY` | Summary output |
| `pt-orc/tools/tools-index.md` | L8 | `MRK:TOOLS_INDEX_FILES` | Files in this directory |

<!-- L2 NAV:v1 → [project root] -->
<!-- L1 ORC-NAV — read MRK:NAV_TOC first; fetch MRK ranges precisely (no default line count) -->
